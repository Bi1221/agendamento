<?php
echo 'teste';?>